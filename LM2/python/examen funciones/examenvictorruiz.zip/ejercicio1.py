def calcularprecio(nombre,precio,cantidad):
    rebaja=estarebajado(nombre)
    if rebaja==False:
        print("El precio del artículo es %.2f €"%(precio*cantidad))
    else:
        print("El precio del artículo es %.2f €"%((precio*cantidad)/2))

def estarebajado(nombre):
    if nombre.find("Rebajas") != -1:
        return(True)
    else:
        return(False)
